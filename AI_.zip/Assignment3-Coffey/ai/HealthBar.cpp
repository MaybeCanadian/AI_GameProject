#include "HealthBar.h"

HealthBar::HealthBar(int w, int h)
{
	health = 100;
	maxHealth = 100;
	pos = { 0, 0 , w, h };
}

void HealthBar::setHealth(int heal)
{
	health = heal;
}

void HealthBar::takeDamage(int damage)
{
	health = health - damage;

	if (health < 0)
	{
		health = 0;
	}
}

void HealthBar::gainHealth(int heal)
{
	health = health + heal;
	if (health > 100)
	{
		health = 100;
	}
}

int HealthBar::getHealth()
{
	return health;
}

void HealthBar::updatePos(int x, int y)
{
	pos.x = x;
	pos.y = y;
}

void HealthBar::render()
{
	display = { pos.x, pos.y , static_cast<int>(pos.w *  (health / maxHealth)), pos.h };
	border = { pos.x - 1, pos.y - 1, pos.w + 1, display.h + 1 };
	TextureManager::getInstance().setDrawColour(255, 255, 255, 255);
	TextureManager::getInstance().fillRect(&border);
	TextureManager::getInstance().setDrawColour(255, 0, 0, 255);
	TextureManager::getInstance().fillRect(&display);
}

HealthBar::~HealthBar()
{
}
