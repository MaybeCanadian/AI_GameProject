#include "MeleeEnemy.h"

MeleeEnemy::MeleeEnemy(int x, int y, int id, int melid, int punch, int hitid)
{
	texture = id;
	fistid = melid;
	punchid = punch;
	hit = hitid;
	pos = { x, y, 25, 25 };
	fist = new Melee(15, 15, 20, fistid, punchid);
	health = new HealthBar(pos.w + 4, 5);
}

void MeleeEnemy::update()
{
	AI();

	health->updatePos(pos.x, pos.y - 10);
	fist->setPos(pos.x + pos.w/2, pos.y + pos.h /2);
	fist->setRotation(rotation);

	fist->updateAI(shouldattack);

	if (health->getHealth() == 0)
	{
		active = false;
	}

	if (invlual > 0)
	{
		invlual--;
	}

}

void MeleeEnemy::Attack()
{
	lookrange = 10000;
	SDL_Point buffer = { pos.x, pos.y };
	rotation = Util::Rotation(&nearPlayer, &buffer);
	shouldattack = false;
	if (look() == true)
	{
		for (int i = 0; i < ObjectManager::getInstance().getPlayerSize(); i++)
		{
			if (Util::distance(&pos, ObjectManager::getInstance().getPlayer(i)->getRect()) < 60)
			{
				 shouldattack = true;
			}
		}


		clearPath();
		if (PathfindingManager::getInstance().findPath(&path, pos.x, pos.y, nearPlayer.x, nearPlayer.y));
		{
			if (path.size() > 0)
			{
				seek(&path.front());
			}
		}
	}
	else
	{
		state = idle;
	}
}


void MeleeEnemy::render()
{
	TextureManager::getInstance().draw(texture, NULL, &pos);

	health->render();

	fist->render();
}


MeleeEnemy::~MeleeEnemy()
{
	delete fist;
}
