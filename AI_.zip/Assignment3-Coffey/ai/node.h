#pragma once
#include "PathfindingManager.h"

class node
{
private:
	SDL_Point pos;
	node* neighbours[4];
	node* parent;
	bool passable;
	int dist;
	bool fleerpoint;
	bool data[3];
	int cost;

public:
	node(int x, int y, bool pass, bool flee);
	void setDist(int input);
	int getDist();
	node* getNeighbour(int side);
	void setNeighbour(int side, node* input);
	node* getParent();
	void setParent(node* input);
	void resetNode();
	void resetNeighbours();
	bool getPassable();
	void setPassable(bool input);
	bool getFlee();
	void setFlee(int input);
	void setBoolData(int type, bool input);
	bool getBoolData(int type);
	SDL_Point * getPoint();
	int getCost();
	void setCost(int input);
	~node();
};

