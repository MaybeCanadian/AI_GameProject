#include "Button.h"

Button::Button()
{
}

void Button::render()
{
	TextureManager::getInstance().draw(textureId, NULL, &pos);
}

void Button::update()
{
	if (InputManager::getInstance().getMouseClick(SDL_BUTTON_LEFT))
	{
		SDL_Rect buffer = { InputManager::getInstance().getMouse()->x, InputManager::getInstance().getMouse()->y, 1, 1 };
		if (SDL_HasIntersection(&buffer, &pos))
		{
			onClick();
		}
	}
}

Button::~Button()
{
}
