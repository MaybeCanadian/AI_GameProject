#pragma once
#include "Player.h"

class HealthBar
{
private:
	double health, maxHealth;
	SDL_Rect pos;
	SDL_Rect display;
	SDL_Rect border;

public:
	HealthBar(int w, int h);
	void setHealth(int heal);
	void takeDamage(int damage);
	void gainHealth(int heal);
	int getHealth();
	void updatePos(int x, int y);
	void render();
	~HealthBar();
};

