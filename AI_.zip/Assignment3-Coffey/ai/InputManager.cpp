#include "InputManager.h"

InputManager::InputManager()
{
}

InputManager & InputManager::getInstance()
{
	static InputManager instance;
	return instance;
}

bool InputManager::init()
{
	mousescroll = false;
	g_iKeystates = SDL_GetKeyboardState(nullptr);
	mouse = { 0, 0 };

	return true;
}

void InputManager::clean()
{
	std::cout << "Input Manager cleaned." << std::endl;
}

bool InputManager::keyDown(SDL_Scancode input)
{
	if (g_iKeystates != nullptr)
	{
		if (g_iKeystates[input] == 1)
		{
			return true;
		}
		else return false;
	}
	else return false;
}

void InputManager::mouseDown(int input)
{
	mouseState[input] = true;
	mouseClick[input] = true;
}

void InputManager::mouseUp(int input)
{
	mouseState[input] = false;
}

SDL_Point * InputManager::getMouse()
{
	return &mouse;
}

void InputManager::update()
{
	SDL_GetMouseState(&mouse.x, &mouse.y);

	for (int i = 0; i < 3; i++)
	{
		mouseClick[i] = false;
	}

	spacePress = false;
	mousescroll = false;
}

bool InputManager::getMouseClick(int button)
{
	return mouseClick[button];
}

bool InputManager::getMouseState(int button)
{
	return mouseState[button];
}

void InputManager::mouseScrollevent()
{
	mousescroll = true;
}

bool InputManager::getscroll()
{
	return mousescroll;
}

InputManager::~InputManager()
{
}
