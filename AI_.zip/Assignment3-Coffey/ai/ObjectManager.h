#pragma once
#include "engine.h"
#include "Player.h"
#include "Enemy.h"
#include "ProgressBar.h"

class Player;
class Melee;
class Enemy;
class ProgressBar;
class ObjectManager
{
private:
	std::vector<Player*> player;
	std::vector<Enemy*> enemies;

	int maxenemies;

	int enemrespawntimer;

	int enemid1, enemid2, playerid, bulletid, rangedid, meleeid;
	int shotid, shotid2, punchid, enemhit;

	std::vector<ProgressBar*> progress;

private:
	ObjectManager();

public:
	static ObjectManager& getInstance();
	bool init();
	void update();
	void render();
	void clean();
	void addPlayer();
	void clearPlayers();
	int getPlayerSize();
	Player* getPlayer(int i);
	void addEnemy(int x, int y, int type);
	void addProgress();
	void clearProgress();
	void clearEnemies();
	int getEnemySize();
	Enemy* getEnemy(int i);
	~ObjectManager();
};

