#pragma once
#include "UiManager.h"

class Button
{
protected:
	SDL_Rect pos;
	SDL_Rect SRC;

	int textureId;

protected:
	virtual void onClick() = 0;

public:
	Button();
	void render();
	void update();
	~Button();
};

#include "ExitButton.h"
#include "StartButton.h"
#include "MenuButton.h"
