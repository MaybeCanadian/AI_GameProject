#pragma once
#include "Button.h"
class ExitButton :
	public Button
{
private:
	void onClick();

public:
	ExitButton(int x, int y, int w, int h, int id);
	~ExitButton();
};

