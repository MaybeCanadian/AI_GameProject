#pragma once
#include "engine.h"

class InputManager
{
private:
	const Uint8* g_iKeystates;
	bool mouseState[3];
	bool mouseClick[3];
	bool spacePress;
	bool mousescroll;

	SDL_Point mouse;

private:
	InputManager();
public:
	static InputManager& getInstance();
	bool init();
	void clean();
	bool keyDown(SDL_Scancode input);
	void mouseDown(int input);
	void mouseUp(int input);
	SDL_Point* getMouse();
	void update();
	bool getMouseClick(int button);
	bool getMouseState(int button);
	void mouseScrollevent();
	bool getscroll();
	~InputManager();
};

