#pragma once
#include "Enemy.h"
#include "Ranged.h"

class Ranged;
class RangedEnemy :
	public Enemy
{
private:
	Ranged* gun;
	int texture, rangedid, bulletid, blastid;

private:
	void Attack();

public:
	RangedEnemy(int x, int y, int id, int ranid, int bulid, int shotid, int hitid);
	void update();
	void render();
	~RangedEnemy();
};

