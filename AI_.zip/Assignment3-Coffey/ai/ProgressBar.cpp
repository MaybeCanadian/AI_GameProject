#include "ProgressBar.h"


ProgressBar::ProgressBar(int x, int y, int w, int h, int goal)
{
	progress = 0;
	this->goal = goal;
	pos = { x, y, w, h };
}

void ProgressBar::setProgress(int input)
{
	progress = input;
}

void ProgressBar::addProgress(int input)
{
	progress = progress + input;
}

void ProgressBar::removeProgress(int input)
{
	progress = progress - input;
}

int ProgressBar::getProgress()
{
	return progress;
}

bool ProgressBar::checkGoal()
{
	if (progress >= goal)
	{
		return true;
	}
	else
		return false;
}

void ProgressBar::setGoal(int input)
{
	goal = input;
}

int ProgressBar::getGoal()
{
	return goal;
}

void ProgressBar::update()
{
}

void ProgressBar::render()
{
	display = { pos.x, pos.y , static_cast<int>(pos.w *  (progress/goal)), pos.h };
	border = { pos.x - 1, pos.y - 1, pos.w + 1, display.h + 1 };
	TextureManager::getInstance().setDrawColour(0, 0, 0, 0);
	TextureManager::getInstance().fillRect(&border);
	TextureManager::getInstance().setDrawColour(255, 255, 255, 255);
	TextureManager::getInstance().fillRect(&display);
}

ProgressBar::~ProgressBar()
{
}
