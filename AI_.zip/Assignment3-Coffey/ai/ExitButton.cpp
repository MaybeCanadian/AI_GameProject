#include "ExitButton.h"

ExitButton::ExitButton(int x, int y, int w, int h, int id)
{
	pos = {x, y, w, h};
	textureId = id;
}

void ExitButton::onClick()
{
	engine::getInstance().quit();
}


ExitButton::~ExitButton()
{
}
