#pragma once
#include "StateMachine.h"

class State
{
public:
	State();
	virtual void update() =0;
	virtual void handleEvents() =0;
	virtual void render() =0;
	virtual void enter() =0;
	virtual void exit() =0;
	~State();
};

#include "StateMenu.h"
#include "StateGame.h"
#include "StatePause.h"
#include "StateLose.h"
#include "StateWin.h"
