#pragma once
#include "ObjectManager.h"


class ProgressBar
{
private:
	double progress, goal;
	SDL_Rect pos;
	SDL_Rect display;
	SDL_Rect border;

public:
	ProgressBar(int x, int y, int w, int h, int goal);
	void setProgress(int input);
	void addProgress(int input);
	void removeProgress(int input);
	int getProgress();
	bool checkGoal();
	void setGoal(int input);
	int getGoal();
	void update();
	void render();
	~ProgressBar();
};

