#include "MenuButton.h"


void MenuButton::onClick()
{
	StateMachine::getInstance().changeState(menu);
}

MenuButton::MenuButton(int x, int y, int w, int h, int id)
{
	pos = { x, y, w, h };
	textureId = id;
}

MenuButton::~MenuButton()
{
}
