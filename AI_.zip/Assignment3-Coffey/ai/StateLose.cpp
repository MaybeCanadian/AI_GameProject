#include "StateLose.h"



StateLose::StateLose()
{
	soundid = AudioManager::getInstance().addSound("lose.wav");
}

void StateLose::update()
{
	BackGroundManager::getInstance().update();
	LevelManager::getInstance().update();
	ObjectManager::getInstance().update();
	UiManager::getInstance().update();
	InputManager::getInstance().update();
}

void StateLose::render()
{
	BackGroundManager::getInstance().GameRender();
	LevelManager::getInstance().render();
	ObjectManager::getInstance().render();
	UiManager::getInstance().render();
}

void StateLose::handleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			engine::getInstance().quit();
			break;
		case SDL_KEYDOWN: // records a key press event
			if (event.key.keysym.sym == SDLK_ESCAPE)
				StateMachine::getInstance().changeState(menu);
			break;
		case SDL_MOUSEBUTTONDOWN: //records a mouse down event
			InputManager::getInstance().mouseDown(event.button.button);
			break;
		case SDL_MOUSEBUTTONUP: //records a mouse up event
			InputManager::getInstance().mouseUp(event.button.button);
			break;
		case SDL_MOUSEWHEEL:
			InputManager::getInstance().mouseScrollevent();
			break;
		}
	}
}

void StateLose::enter()
{
	UiManager::getInstance().addButton(WIDTH / 2 - 100, HEIGHT / 2 - 50, 200, 100, menubutton);
	AudioManager::getInstance().playSound(soundid, -1, 0);
}

void StateLose::exit()
{
	ObjectManager::getInstance().clearPlayers();
	UiManager::getInstance().clearButtons();
}


StateLose::~StateLose()
{
}
