#pragma once
#include "State.h"

class StateMenu :
	public State
{
public:
	StateMenu();
	void update();
	void render();
	void handleEvents();
	void enter();
	void exit();
	~StateMenu();
};

