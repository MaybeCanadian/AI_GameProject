#pragma once
#include "LevelManager.h"

class node;
class Wall
{
protected:
	SDL_Rect pos;
	SDL_Rect inner;
	int textureId, soundid;
	node* buffer;

public:
	Wall(int x, int y, int w, int h, int id, node* wallnode, int sound);
	Wall();
	virtual void render();
	virtual void update();
	SDL_Rect* getRect();
	virtual bool getActive();
	virtual void onHit(int damage, int inv);
	~Wall();
};

#include "DestructableWall.h"

