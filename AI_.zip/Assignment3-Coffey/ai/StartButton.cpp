#include "StartButton.h"


void StartButton::onClick()
{
	StateMachine::getInstance().changeState(game);
}

StartButton::StartButton(int x, int y, int w, int h, int id)
{
	pos = { x, y, w, h };
	textureId = id;
}

StartButton::~StartButton()
{
}
