#pragma once


class Util
{
public:
	static double min(double input1, double input2) //returns the mix
	{
		if (input1 > input2)
			return input2;
		else
			return input1;
	}

	static double max(double input1, double input2) //returns the max
	{
		if (input1 > input2)
			return input1;
		else
			return input2;
	}

	static double Rotation(SDL_Point* p1, SDL_Point* p2) //player p2, mouse p1, in degrees
	{			
		return (atan2((p1->y - p2->y), (p1->x - p2->x)));
	}

	static double distance(SDL_Rect* in1, SDL_Rect* in2)
	{
		return sqrt(pow(in1->x - in2->x, 2) + pow(in1->y - in2->y, 2));
	}

	static double Trunacate(double value1, double value2)
	{
		if (value1 < value2)
			return value1;
		else
			return value2;
	}
};
