#pragma once
#include "State.h"
class StateGame :
	public State
{
public:
	StateGame();
	void update();
	void render();
	void handleEvents();
	void exit();
	void enter();
	~StateGame();
};

