#pragma once
#include "engine.h"
#include "State.h"


class State;
class StateMachine
{
private:
	State* states[5];
	int state;

private:
	StateMachine();

public:
	static StateMachine& getInstance();
	bool init();
	void clean();
	void update();
	void render();
	void handleEvents();
	void changeState(int input);
	~StateMachine();
};

