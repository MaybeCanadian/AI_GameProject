#include "Bullet.h"


void Bullet::checkcollision()
{
	if (pos.x < 0 || pos.x + pos.w > WIDTH)
	{
		active = false;
	}
	if (pos.y < 0 || pos.y + pos.h > HEIGHT)
	{
		active = false;
	}

	for (int i = 0; i < LevelManager::getInstance().getWallSize(); i++)
	{
		if (SDL_HasIntersection(&pos, LevelManager::getInstance().getWall(i)->getRect()))
		{
			active = false;
			LevelManager::getInstance().getWall(i)->onHit(10, 5);
		}
	}

	for (int i = 0; i < ObjectManager::getInstance().getEnemySize(); i++)
	{
		if (SDL_HasIntersection(&pos, ObjectManager::getInstance().getEnemy(i)->getRect()))
		{
			active = false;
			ObjectManager::getInstance().getEnemy(i)->onHit(10, 5);
		}
	}
}

void Bullet::checkCollisionAI()
{
	if (pos.x < 0 || pos.x + pos.w > WIDTH)
	{
		active = false;
	}
	if (pos.y < 0 || pos.y + pos.h > HEIGHT)
	{
		active = false;
	}

	for (int i = 0; i < LevelManager::getInstance().getWallSize(); i++)
	{
		if (SDL_HasIntersection(&pos, LevelManager::getInstance().getWall(i)->getRect()))
		{
			active = false;
			LevelManager::getInstance().getWall(i)->onHit(10, 5);
		}
	}

	for (int i = 0; i < ObjectManager::getInstance().getPlayerSize(); i++)
	{
		if (SDL_HasIntersection(&pos, ObjectManager::getInstance().getPlayer(i)->getRect()))
		{
			active = false;
			ObjectManager::getInstance().getPlayer(i)->onHit(10, 5);
		}
	}
}

Bullet::Bullet(int x, int y, int w, int h, double accel, double rot, bool ty, int id)
{
	pos = { x, y, w, h };
	rotation = rot;
	accelx = accel * cos(rotation);
	accely = accel * sin(rotation);
	velx = vely = 0;
	maxVel = 50;
	drag = 1;
	active = true;
	ai = ty;
	texture = id;
}

void Bullet::update()
{
	velx = (velx + accelx) * drag;
	vely = (vely + accely) * drag;

	accelx = accely = 0;

	velx = Util::min(Util::max(velx, -maxVel), maxVel);
	vely = Util::min(Util::max(vely, -maxVel), maxVel);

	pos.x = pos.x + (int)velx;
	pos.y = pos.y + (int)vely;

	if (ai == true)
	{
		checkCollisionAI();
	}
	else
	{
		checkcollision();
	}
}

void Bullet::updateAI()
{
	velx = (velx + accelx) * drag;
	vely = (vely + accely) * drag;

	accelx = accely = 0;

	velx = Util::min(Util::max(velx, -maxVel), maxVel);
	vely = Util::min(Util::max(vely, -maxVel), maxVel);

	pos.x = pos.x + (int)velx;
	pos.y = pos.y + (int)vely;

	checkCollisionAI();
}

void Bullet::render()
{
	TextureManager::getInstance().drawEX(texture, NULL, &pos, rotation, NULL, SDL_FLIP_NONE);
}

bool Bullet::getActive()
{
	return active;
}

SDL_Rect * Bullet::getRect()
{
	return &pos;
}

Bullet::~Bullet()
{
}
