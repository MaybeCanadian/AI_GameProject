#pragma once
#include "Button.h"
class MenuButton :
	public Button
{
private:
	void onClick();

public:
	MenuButton(int x, int y, int w, int h, int id);
	~MenuButton();
};

