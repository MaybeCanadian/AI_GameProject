#include "node.h"

node::~node()
{
}

node::node(int x, int y, bool pass, bool flee)
{
	pos = { x, y };
	passable = pass;
	dist = 10000;
	cost = 1;
	fleerpoint = flee;
	for (int i = 0; i < 3; i++)
	{
		data[i] = false;
	}
	for (int i = 0; i < 4; i++)
	{
		neighbours[i] = nullptr;
	}
}

void node::setDist(int input)
{
	dist = input;
}

int node::getDist()
{
	return dist;
}

node * node::getNeighbour(int side)
{
	return neighbours[side];
}

void node::setNeighbour(int side, node * input)
{
	neighbours[side] = input;
}

node * node::getParent()
{
	return parent;
}

void node::setParent(node * input)
{
	parent = input;
}

void node::resetNode()
{
	dist = 10000;
	parent = nullptr;
	data[0] = false; //start
	data[1] = false; //end
	data[2] = false; //visited
}

void node::resetNeighbours()
{
	for (int i = 0; i < 4; i++)
	{
		neighbours[i] = nullptr;
	}
}

bool node::getPassable()
{
	return passable;
}

void node::setPassable(bool input)
{
	passable = input;
}

bool node::getFlee()
{
	return fleerpoint;
}

void node::setFlee(int input)
{
	fleerpoint = input;
}

void node::setBoolData(int type, bool input)
{
	data[type] = input;
}

bool node::getBoolData(int type)
{
	return data[type];
}

SDL_Point * node::getPoint()
{
	return &pos;
}

int node::getCost()
{
	return cost;
}

void node::setCost(int input)
{
	cost = input;
}
