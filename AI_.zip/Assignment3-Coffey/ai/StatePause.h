#pragma once
#include "State.h"
class StatePause :
	public State
{
public:
	StatePause();
	void update();
	void handleEvents();
	void render();
	void exit();
	void enter();
	~StatePause();
};

