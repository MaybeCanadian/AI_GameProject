#include "State.h"



State::State()
{
}

void State::update()
{
}

void State::handleEvents()
{
}

void State::render()
{
}

void State::enter()
{
}

void State::exit()
{
}


State::~State()
{
}
