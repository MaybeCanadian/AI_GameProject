#pragma once
#include <SDL_mixer.h>

#include "engine.h"

class AudioManager
{
private:
	std::vector<Mix_Chunk*> sounds;

private:
	AudioManager();

public:
	static AudioManager& getInstance();
	bool init();
	int addSound(std::string input);
	void playSound(int id, int chanel, int loops);
	void clean();
	~AudioManager();
};

