#pragma once
#include "Player.h"

class Melee
{
private:
	SDL_Rect pos;
	SDL_Rect inner;
	double rotation;
	SDL_Point holdPos;
	bool attacking;
	int attackTimer;
	int fistrange;
	int attackrange;
	bool damage;
	int textureid, soundid;

private:
	void checkCollision();
	void checkCollisionAI();

public:
	Melee(int w, int h, int range, int id, int sound);
	void update();
	void updateAI(bool attack);
	void render();
	void setPos(int x, int y);
	void setRotation(double rot);
	bool getAttacking();
	SDL_Rect* getRect();
	void wepChange();
	~Melee();
};

