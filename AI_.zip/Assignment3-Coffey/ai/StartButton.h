#pragma once
#include "Button.h"
class StartButton :
	public Button
{
private:
	void onClick();

public:
	StartButton(int x, int y, int w, int h, int id);
	~StartButton();
};

