#pragma once

//library includes
#include <SDL.h>
#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include <algorithm>
#include <time.h>

//file includes
#include "enum.h"
#include "Util.h"
#include "TextureManager.h"
#include "AudioManager.h"
#include "StateMachine.h"
#include "ObjectManager.h"
#include "InputManager.h"
#include "UiManager.h"
#include "BackGroundManager.h"
#include "LevelManager.h"
#include "PathfindingManager.h"

//definitions
#define WIDTH 1080
#define HEIGHT 640
#define FPS 60


class TextureManager;
class AudioManager;
class StateMachine;
class ObjectManager;
class InputManager;
class UiManager;
class BackGroundManager;
class LevelManager;
class PathfindingManager;
class engine
{
private:
	bool running;
	Uint8 fps, start, end, delta;

private:
	engine();
	void wake();
	void sleep();
	void update();
	void render();
	void handleEvents();
	void clean();
	bool init(const char * title, int xpos, int ypos, int width, int height, int flags);

public:
	static engine& getInstance();
	int run();
	void quit();
	~engine();
};

