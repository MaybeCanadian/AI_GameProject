#include "TextureManager.h"



TextureManager::TextureManager()
{
	t_pRenderer = nullptr;
	t_pWindow = nullptr;
}

TextureManager & TextureManager::getInstance()
{
	static TextureManager instance;
	return instance;
}

bool TextureManager::init(const char * title, int xpos, int ypos, int width, int height, int flags)
{
	t_pWindow = SDL_CreateWindow(title, xpos, ypos, width, height, flags);

	if (t_pWindow != nullptr)
	{
		t_pRenderer = SDL_CreateRenderer(t_pWindow, -1, flags);

		if (t_pRenderer != nullptr)
		{
			std::cout << "Texture Manager loaded" << std::endl;
			return true;
		}
		else
			return false;
	}
	else
		return false;

	return false;
}

int TextureManager::addTexture(std::string input)
{
	const char* buffer = input.c_str();

	textures.push_back(IMG_LoadTexture(t_pRenderer, buffer));

	if (textures.back() == nullptr)
	{
		textures.pop_back();
		return -1;
	}

	return (textures.size() - 1);
}

void TextureManager::draw(int id, SDL_Rect * area, SDL_Rect * pos)
{
	SDL_RenderCopy(t_pRenderer, textures[id], area, pos);
}

void TextureManager::drawEX(int id, SDL_Rect * area, SDL_Rect * pos, double rot, SDL_Point * centre, SDL_RendererFlip flip)
{
	SDL_RenderCopyEx(t_pRenderer, textures[id], area, pos, rot, centre, flip);
}

void TextureManager::clean()
{
	for (int i = 0; i < (int)textures.size(); i++)
	{
		SDL_DestroyTexture(textures[i]);
	}

	textures.clear();
	textures.shrink_to_fit();

	std::cout << "Texture Manager cleaned." << std::endl;
}

void TextureManager::setDrawColour(Uint8 r, Uint8 g, Uint8 b, Uint8 a)
{
	SDL_SetRenderDrawColor(t_pRenderer, r, g, b, a);
}

void TextureManager::fillRect(SDL_Rect * pos)
{
	SDL_RenderFillRect(t_pRenderer, pos);
}

void TextureManager::renderPresent()
{
	SDL_RenderPresent(t_pRenderer);
}

void TextureManager::renderClear()
{
	SDL_RenderClear(t_pRenderer);
}

TextureManager::~TextureManager()
{
}
