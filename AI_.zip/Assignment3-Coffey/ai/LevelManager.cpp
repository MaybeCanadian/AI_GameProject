#include "LevelManager.h"

LevelManager::LevelManager()
{
	reload = false;
}

LevelManager & LevelManager::getInstance()
{
	static LevelManager instance;
	return instance;
}

bool LevelManager::init()
{
	wallID = TextureManager::getInstance().addTexture("wall.png");
	destructID = TextureManager::getInstance().addTexture("destruct.png");
	hitsound = AudioManager::getInstance().addSound("hit.wav");
	std::cout << "Level Manager Loaded." << std::endl;
	return true;
}

void LevelManager::clean()
{
	clearWalls();
	std::cout << "Level Manager cleaned." << std::endl;
}

bool LevelManager::LoadLevel()
{
	std::fstream file("map.txt");

	if (!file.is_open())
	{
		std::cout << "error opening map file." << std::endl;
		return false;
	}

	int cols, rows;
	std::string line;
	char input;
	node* buffer;

	file >> cols >> rows;

	if (!file.eof())
	{
		for (int row = 0; row < rows; row++)
		{
			file >> line;

			for (int col = 0; col < cols; col++)
			{
				input = line.at(col);

				switch (input)
				{
				case '0':
				{
					PathfindingManager::getInstance().addNode(GRID * col, GRID * row, GRID, GRID, true, false);
					break;
				}
				case '1':
				{
					buffer = PathfindingManager::getInstance().addNode(GRID * col, GRID * row, GRID, GRID, false, false);
					walls.push_back(new Wall(col * GRID, row * GRID, GRID, GRID, wallID, buffer, hitsound));
					break;
				}
				case '2':
				{
					buffer = PathfindingManager::getInstance().addNode(GRID * col, GRID * row, GRID, GRID, false, false);
					walls.push_back(new DestructableWall(col* GRID, row * GRID, GRID, GRID, destructID, buffer, hitsound));
					break;
				}
				case '3':
				{
					PathfindingManager::getInstance().addNode(GRID * col, GRID * row, GRID, GRID, true, true);
					break;
				}
				}
			}
		}
	}

	PathfindingManager::getInstance().setRowCol(rows, cols);
	PathfindingManager::getInstance().loadNeighbours();

	std::cout << "Level Loaded." << std::endl;
	return true;
}

void LevelManager::clearWalls()
{
	if (!walls.empty())
	{
		for (int i = 0; i < (int)walls.size(); i++)
		{
			delete walls[i];
			walls[i] = nullptr;
		}

		walls.clear();
		walls.shrink_to_fit();
	}
}

void LevelManager::update()
{
	if (!walls.empty())
	{
		for (int i = 0; i < (int)walls.size(); i++)
		{
			walls[i]->update();
		}

		for (int i = 0; i < (int)walls.size(); i++)
		{
			if (walls[i]->getActive() == false)
			{
				delete walls[i];
				walls[i] = nullptr;
				reload = true;
			}
		}

		walls.erase(std::remove(walls.begin(), walls.end(), nullptr), walls.end());
	}

	if (reload == true)
	{
		PathfindingManager::getInstance().loadNeighbours();
		reload = false;
	}
}

void LevelManager::render()
{
	if (!walls.empty())
	{
		for (int i = 0; i < (int)walls.size(); i++)
		{
			walls[i]->render();
		}
	}
}

int LevelManager::getWallSize()
{
	return walls.size();;
}

Wall * LevelManager::getWall(int i)
{
	return walls[i];
}

LevelManager::~LevelManager()
{
}
