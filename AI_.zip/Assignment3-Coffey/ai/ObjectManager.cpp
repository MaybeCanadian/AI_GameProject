#include "ObjectManager.h"

ObjectManager::ObjectManager()
{
	enemrespawntimer = 300;
	maxenemies = 2;
}

ObjectManager & ObjectManager::getInstance()
{
	static ObjectManager instance;
	return instance;
}

bool ObjectManager::init()
{
	enemid1 = TextureManager::getInstance().addTexture("melee.png");
	enemid2 = TextureManager::getInstance().addTexture("ranged.png");
	playerid = TextureManager::getInstance().addTexture("player.png");
	rangedid = TextureManager::getInstance().addTexture("gun.png");
	meleeid = TextureManager::getInstance().addTexture("fist.png");
	bulletid = TextureManager::getInstance().addTexture("bullet.png");
	shotid = AudioManager::getInstance().addSound("blast.wav");
	shotid2 = AudioManager::getInstance().addSound("blaster.wav");
	punchid = AudioManager::getInstance().addSound("whosh.wav");
	enemhit = AudioManager::getInstance().addSound("enemhit.wav");
	std::cout << "Object Manager init." << std::endl;
	return true;
}

void ObjectManager::update()
{
	if (!player.empty())
	{
		for (int i = 0; i < (int)player.size(); i++)
		{
			player[i]->update();
		}
	}

	if (!player.empty())
	{
		for (int i = 0; i < (int)player.size(); i++)
		{
			if (player[i]->getAcive() == false)
			{
				delete player[i];
				player[i] = nullptr;
			}
		}

		player.erase(std::remove(player.begin(), player.end(), nullptr), player.end());
	}

	if (!enemies.empty())
	{
		for (int i = 0; i < (int)enemies.size(); i++)
		{
			enemies[i]->update();
		}
	}

	if (!enemies.empty())
	{
		for (int i = 0; i < (int)enemies.size(); i++)
		{
			if (enemies[i]->getActive() == false)
			{
				delete enemies[i];
				enemies[i] = nullptr;
				enemrespawntimer = 300;
				if (!progress.empty())
				{
					for (int i = 0; i < (int)progress.size(); i++)
					{
						progress[i]->addProgress(50);
					}
				}
			}
		}

		enemies.erase(std::remove(enemies.begin(), enemies.end(), nullptr), enemies.end());


		if (enemies.size() > 0)
		{
			if (enemies.size() < maxenemies)
			{
				if (enemrespawntimer == 0)
				{
					srand(time(NULL));

					int type = rand() % 2;

					switch (type)
					{
					case 0:
					{
						addEnemy(GRID * 12, GRID * 15, melee);
						enemrespawntimer = 300;
						if (!progress.empty())
						{
							for (int i = 0; i < (int)progress.size(); i++)
							{
								progress[i]->removeProgress(50);
							}
						}
						break;
					}
					case 1:
					{
						addEnemy(GRID * 0, GRID * 8, ranged);
						enemrespawntimer = 300;
						if (!progress.empty())
						{
							for (int i = 0; i < (int)progress.size(); i++)
							{
								progress[i]->removeProgress(50);
							}
						}
						break;
					}
					}
				}
				else
				{
					enemrespawntimer--;
				}
			}
		}
	}


	if (!progress.empty())
	{
		for (int i = 0; i < (int)progress.size(); i++)
		{
			if (progress[i]->checkGoal())
			{
				StateMachine::getInstance().changeState(win);
			}
		}
	}
}

void ObjectManager::render()
{
	if (!player.empty())
	{
		for (int i = 0; i < (int)player.size(); i++)
		{
			player[i]->render();
		}
	}

	if (!enemies.empty())
	{
		for (int i = 0; i < (int)enemies.size(); i++)
		{
			enemies[i]->render();
		}
	}

	if (!progress.empty())
	{
		for (int i = 0; i < (int)progress.size(); i++)
		{
			progress[i]->render();
		}
	}
}

void ObjectManager::clean()
{
	clearPlayers();
	
	clearEnemies();

	std::cout << "Object Manager cleaned." << std::endl;
}

void ObjectManager::addPlayer()
{
	player.push_back(new Player(playerid, rangedid, bulletid, meleeid, shotid, punchid));
}

void ObjectManager::clearPlayers()
{
	if (!player.empty())
	{
		for (int i = 0; i < (int)player.size(); i++)
		{
			delete player[i];
		}

		player.clear();
		player.shrink_to_fit();
	}
}

int ObjectManager::getPlayerSize()
{
	return player.size();
}

Player * ObjectManager::getPlayer(int i)
{
	return player[i];
}

void ObjectManager::addEnemy(int x, int y, int type)
{
	switch (type)
	{
	case melee:
	{		
		enemies.push_back(new MeleeEnemy(x, y, enemid1, meleeid, punchid, enemhit));
		break;
	}
	case ranged:
	{
		enemies.push_back(new RangedEnemy(x, y, enemid2, rangedid, bulletid, shotid2, enemhit));
		break;
	}
	}
}

void ObjectManager::addProgress()
{
	progress.push_back(new ProgressBar(5, 5, 100, 10, 100));
}

void ObjectManager::clearProgress()
{
	if (!progress.empty())
	{
		for (int i = 0; i < (int)progress.size(); i++)
		{
			delete progress[i];
		}

		progress.clear();
		progress.shrink_to_fit();
	}
}

void ObjectManager::clearEnemies()
{
	if (!enemies.empty())
	{
		for (int i = 0; i < (int)enemies.size(); i++)
		{
			delete enemies[i];
			enemies[i] == nullptr;
		}

		enemies.clear();
		enemies.shrink_to_fit();
	}
}

int ObjectManager::getEnemySize()
{
	return enemies.size();
}

Enemy * ObjectManager::getEnemy(int i)
{
	return enemies[i];
}

ObjectManager::~ObjectManager()
{
}
