#pragma once
#include "ObjectManager.h"
#include "HealthBar.h"
#include "Melee.h"
#include "Ranged.h"

class HealthBar;
class Melee;
class Ranged;
class Player
{
private:
	HealthBar* health;
	Melee* fist;
	Ranged* gun;

	SDL_Rect dst;
	SDL_Rect SRC;

	bool active;

	double accelx, accely, velx, vely, accel, dashaccely, dashaccelx, dashaccel;

	double maxVel, maxAccel, drag, maxVeldash;

	double direction, rotation;

	int gundist;

	int invaul;

	int currentWep, wepSwapTimer, dashTimer, dashDuration;

	bool dashing;

	int textureID, rangedid, fistid, bulletid, shotid, attackid;

private:
	void move();
	void followMouse();
	void checkCollisions();
	void correctcollision(SDL_Rect* plat);
	void dash();

public:
	Player(int id, int rangid, int bulid, int melid, int blastid, int punchid);
	void update();
	void render();
	SDL_Rect* getRect();
	void onHit(int damage, int inv);
	bool getAcive();
	~Player();
};

