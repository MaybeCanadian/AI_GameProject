#include "DestructableWall.h"

DestructableWall::DestructableWall(int x, int y, int w, int h, int id, node* wallnode, int sound)
{
	pos = { x, y, w, h };
	textureId = id;
	health = new HealthBar(pos.w, 5);
	active = true;
	invaul = 0;
	buffer = wallnode;
	soundid = sound;
}

void DestructableWall::render()
{
	TextureManager::getInstance().draw(textureId, NULL, &pos);

	if (health->getHealth() < 100)
	{
		health->render();
	}
}

bool DestructableWall::getActive()
{
	return active;
}

void DestructableWall::update()
{

	if (invaul > 0)
	{
		invaul--;
	}

	health->updatePos(pos.x, pos.y - 10);
	if (health->getHealth() <= 0)
	{
		active = false;
		buffer->setPassable(true);
	}
}

void DestructableWall::setActive(bool input)
{
	active = input;
}

void DestructableWall::onHit(int damage, int inv)
{
	//do damage
	if (invaul == 0)
	{
		AudioManager::getInstance().playSound(soundid, -1, 0);
		health->takeDamage(damage);
		invaul = 30;
	}
	//make sound
}

DestructableWall::~DestructableWall()
{
	delete health;
}
