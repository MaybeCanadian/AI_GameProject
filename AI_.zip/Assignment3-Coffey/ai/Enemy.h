#pragma once
#include "ObjectManager.h"
#include "HealthBar.h"

class HealthBar;
class Enemy
{
protected:
	SDL_Rect pos;
	SDL_Rect SRC;

	HealthBar* health;
	int state;
	int lookrange;
	bool exit;
	bool shouldattack;

	int hit;

	enum {
		idle, attacking, backing, fleeing
	};

	std::vector<SDL_Point> path;

	int wandergoal, wanderplace, wandertimer;

	double velx, vely, steerx, steery, desx, desy;

	double MaxVel, Maxforce;

	SDL_Point nearPlayer;

	int invlual;

	bool active;

	double rotation;

protected:
	void Flee();
	void seek(SDL_Point* target);
	void checklow();
	void clearPath();
	void Idle();
	void AI();
	virtual void Attack() =0;
	bool look();

public:
	Enemy();
	virtual void update() = 0;
	virtual void render() = 0;
	bool getActive();
	SDL_Rect * getRect();
	void onHit(int damage, int inv);
	~Enemy();
};

#include "MeleeEnemy.h";
#include "RangedEnemy.h"
