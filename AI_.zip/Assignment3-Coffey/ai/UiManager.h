#pragma once
#include "engine.h"
#include "Button.h"

class Button;
class UiManager
{
private:
	std::vector<Button*> buttons;
	int startID, exitID, menuID;

private:
	UiManager();
public:
	static UiManager& getInstance();
	void update();
	void render();
	bool init();
	void clean();
	void addButton(int x, int y, int w, int h, int type);
	void clearButtons();
	~UiManager();
};

