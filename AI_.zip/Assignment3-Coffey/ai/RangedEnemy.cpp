#include "RangedEnemy.h"

void RangedEnemy::Attack()
{
	if (look())
	{
		shouldattack = false;
		SDL_Rect buffer = { nearPlayer.x, nearPlayer.y, 1, 1 };
		if (Util::distance(&pos, &buffer) < 400)
		{
			if (Util::distance(&pos, &buffer) < 100)
			{
				// move back
			}

			SDL_Point pbuffer = { pos.x, pos.y };
			rotation = Util::Rotation(&nearPlayer, &pbuffer);

			shouldattack = true;
		}
		else
		{
			clearPath();
			if (PathfindingManager::getInstance().findPath(&path, pos.x, pos.y, nearPlayer.x, nearPlayer.y))
			{
				seek(&path.front());
			}
		}
	}
	else
	{
		state = idle;
	}
}

RangedEnemy::RangedEnemy(int x, int y, int id, int ranid, int bulid, int shotid, int hitid)
{
	texture = id;
	rangedid = ranid;
	bulletid = bulid;
	blastid = shotid;
	hit = hitid;
	pos = { x, y, 25, 25 };
	gun = new Ranged(10, 10, 20, 30, true, rangedid, bulid, shotid);
	health = new HealthBar(pos.w + 4, 5);
	gun->setActive(true);
}

void RangedEnemy::update()
{

	AI();

	health->updatePos(pos.x, pos.y - 10);

	gun->setPos(pos.x + pos.w / 2, pos.y + pos.h / 2);
	gun->setRot(rotation);

	gun->updateAI(shouldattack);

	if (invlual > 0)
	{
		invlual--;
	}
}

void RangedEnemy::render()
{
	TextureManager::getInstance().draw(texture, NULL, &pos);
	health->render();
	gun->render();
}


RangedEnemy::~RangedEnemy()
{
}
