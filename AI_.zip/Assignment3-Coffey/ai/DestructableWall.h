#pragma once
#include "Wall.h"
#include "LevelManager.h"
#include "HealthBar.h"

class HealthBar;
class DestructableWall :
	public Wall
{
private:
	HealthBar* health;
	bool active;
	int invaul;

public:
	DestructableWall(int x, int y, int w, int h, int id, node* wallnode, int sound);
	void render();
	bool getActive();
	void update();
	void setActive(bool input);
	void onHit(int damage, int inv);
	~DestructableWall();
};

