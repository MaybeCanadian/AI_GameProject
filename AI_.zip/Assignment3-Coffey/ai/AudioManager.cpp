#include "AudioManager.h"



AudioManager::AudioManager()
{
}


AudioManager & AudioManager::getInstance()
{
	static AudioManager instance;
	return instance;
}

bool AudioManager::init()
{
	if (Mix_Init(MIX_INIT_MP3) != 0)
	{
		Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 8192);
		Mix_AllocateChannels(32);
		Mix_Volume(0, MIX_MAX_VOLUME / 2);
		Mix_VolumeMusic(MIX_MAX_VOLUME / 2);

		std::cout << "Sound Manager Loaded." << std::endl;
		return true;
	}

	return false;
}

int AudioManager::addSound(std::string input)
{
	const char* buffer = input.c_str();

	sounds.push_back(Mix_LoadWAV(buffer));

	if (sounds.back() == nullptr)
	{
		sounds.pop_back();
		return -1;
	}

	return (sounds.size() -1);
}

void AudioManager::playSound(int id, int chanel, int loops)
{
	Mix_PlayChannel(chanel, sounds[id], loops);
}

void AudioManager::clean()
{
	for (int i = 0; i < (int)sounds.size(); i++)
	{
		Mix_FreeChunk(sounds[i]);
	}

	sounds.clear();
	sounds.shrink_to_fit();

	std::cout << "Sound Manager cleaned." << std::endl;
}

AudioManager::~AudioManager()
{
}
