#include "StateMenu.h"



StateMenu::StateMenu()
{
}

void StateMenu::update()
{
	UiManager::getInstance().update();
}

void StateMenu::render()
{
	BackGroundManager::getInstance().MenuRender();
	UiManager::getInstance().render();
}

void StateMenu::handleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			engine::getInstance().quit();
			break;
		case SDL_KEYDOWN: // records a key press event
			if (event.key.keysym.sym == SDLK_ESCAPE)
				StateMachine::getInstance().changeState(game);
			break;
		case SDL_MOUSEBUTTONDOWN: //records a mouse down event
			InputManager::getInstance().mouseDown(event.button.button);
			break;
		case SDL_MOUSEBUTTONUP: //records a mouse up event
			InputManager::getInstance().mouseUp(event.button.button);
			break;
		}
	}
}

void StateMenu::enter()
{
	UiManager::getInstance().addButton(WIDTH / 2 - 100, HEIGHT / 2 - 50 - HEIGHT /4, 200, 100, startbutton);
	UiManager::getInstance().addButton(WIDTH / 2 - 100, HEIGHT / 2 - 50 + HEIGHT / 4, 200, 100, exitbutton);
	LevelManager::getInstance().clearWalls();
	ObjectManager::getInstance().clearEnemies();
	ObjectManager::getInstance().clearPlayers();
	ObjectManager::getInstance().clearProgress();
}

void StateMenu::exit()
{
	UiManager::getInstance().clearButtons();
	LevelManager::getInstance().LoadLevel();
	ObjectManager::getInstance().addProgress();

	ObjectManager::getInstance().addPlayer();
	ObjectManager::getInstance().addEnemy(GRID * 12, GRID * 15, melee);
	ObjectManager::getInstance().addEnemy(GRID * 0, GRID * 8, ranged);
}


StateMenu::~StateMenu()
{
}
