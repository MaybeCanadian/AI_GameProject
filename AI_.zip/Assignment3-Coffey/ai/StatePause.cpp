#include "StatePause.h"



StatePause::StatePause()
{
}

void StatePause::update()
{
	UiManager::getInstance().update();
}

void StatePause::handleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			engine::getInstance().quit();
			break;
		case SDL_KEYDOWN: // records a key press event
			if (event.key.keysym.sym == SDLK_ESCAPE)
				StateMachine::getInstance().changeState(game);
			break;
		case SDL_MOUSEBUTTONDOWN: //records a mouse down event
			InputManager::getInstance().mouseDown(event.button.button);
			break;
		case SDL_MOUSEBUTTONUP: //records a mouse up event
			InputManager::getInstance().mouseUp(event.button.button);
			break;
		}
	}
}

void StatePause::render()
{
	BackGroundManager::getInstance().GameRender();
	LevelManager::getInstance().render();
	ObjectManager::getInstance().render();
	UiManager::getInstance().render();
}

void StatePause::exit()
{
	UiManager::getInstance().clearButtons();
}

void StatePause::enter()
{
	UiManager::getInstance().addButton(WIDTH / 2 - 100, HEIGHT / 2 - 50, 200, 100, menubutton);
}


StatePause::~StatePause()
{
}
