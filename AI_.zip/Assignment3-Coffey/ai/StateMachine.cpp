#include "StateMachine.h"



StateMachine::StateMachine()
{
	state = -1;
}

StateMachine & StateMachine::getInstance()
{
	static StateMachine instance;
	return instance;
}

bool StateMachine::init()
{
	states[menu] = new StateMenu();
	states[game] = new StateGame();
	states[pause] = new StatePause();
	states[lose] = new StateLose();
	states[win] = new StateWin();

	changeState(menu);

	return true;
}

void StateMachine::clean()
{
	std::cout << "State Machine cleaned." << std::endl;
}

void StateMachine::update()
{
	states[state]->update();
	InputManager::getInstance().update();
}

void StateMachine::render()
{
	states[state]->render();
	TextureManager::getInstance().renderPresent();
}

void StateMachine::handleEvents()
{
	states[state]->handleEvents();
}

void StateMachine::changeState(int input)
{
	if (state != input)
	{
		TextureManager::getInstance().renderClear();

		if (state != -1)
		{
			states[state]->exit();
		}

		std::cout << "Changing to state to " << input << std::endl;

		state = input;

		states[state]->enter();
	}
}

StateMachine::~StateMachine()
{
}
