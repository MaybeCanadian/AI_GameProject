#pragma once

enum {
	up, down, left, right
};

enum {
	menu, game, pause, lose, win
};

enum {
	startbutton, exitbutton, menubutton,
};

enum {
	melee, ranged
};