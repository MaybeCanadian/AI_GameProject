#include "UiManager.h"



UiManager::UiManager()
{
}

UiManager & UiManager::getInstance()
{
	static UiManager instance;
	return instance;
}

void UiManager::update()
{
	if (!buttons.empty())
	{
		for (int i = 0; i < (int)buttons.size(); i++)
		{
			buttons[i]->update();
		}
	}
}

void UiManager::render()
{
	if (!buttons.empty())
	{
		for (int i = 0; i < (int)buttons.size(); i++)
		{
			buttons[i]->render();
		}
	}
}

bool UiManager::init()
{
	std::cout << "Ui Manager Loaded." << std::endl;
	startID = TextureManager::getInstance().addTexture("play.png");
	exitID = TextureManager::getInstance().addTexture("quit.png");
	menuID = TextureManager::getInstance().addTexture("menu.png");
	return true;
}

void UiManager::clean()
{
	clearButtons();
	std::cout << "Ui Manager cleaned." << std::endl;
}

void UiManager::addButton(int x, int y, int w, int h, int type)
{
	switch (type)
	{
	case startbutton:
	{
		buttons.push_back(new StartButton(x, y, w, h, startID));
		break;
	}
	case exitbutton:
	{
		buttons.push_back(new ExitButton(x, y, w, h, exitID));
		break;
	}
	case menubutton:
	{
		buttons.push_back(new MenuButton(x, y, w, h, menuID));
		break;
	}
	}
}

void UiManager::clearButtons()
{
	if (!buttons.empty())
	{
		for (int i = 0; i < (int)buttons.size(); i++)
		{
			delete buttons[i];
			buttons[i] = nullptr;
		}

		buttons.clear();
		buttons.shrink_to_fit();
	}
}


UiManager::~UiManager()
{
}
