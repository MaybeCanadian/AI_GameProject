#include "Ranged.h"

Ranged::Ranged(int w, int h, int hold, int attackspeed, bool ty, int id, int bulid, int shotid)
{
	pos = { 0, 0, w, h };
	rotation = 0;
	holdrange = hold;
	active = false;
	attackTimer = 0;
	attackspeedduration = attackspeed;
	ai = ty;
	texture = id;
	bulletid = bulid;
	blastid = shotid;
}

void Ranged::update()
{
	pos.x = hold_pos.x + (holdrange * cos(rotation)) - pos.w /2;
	pos.y = hold_pos.y + (holdrange * sin(rotation)) - pos.h /2;

		if (attackTimer == 0)
		{
			if (active == true)
			{
				if (InputManager::getInstance().getMouseState(SDL_BUTTON_LEFT))
				{
					bullets.push_back(new Bullet(pos.x, pos.y, 5, 5, 10, rotation, ai, bulletid));
					AudioManager::getInstance().playSound(blastid, -1, 0);
					attackTimer = attackspeedduration;
				}
			}
		}
		if (attackTimer > 0)
		{
			attackTimer--;
		}

	if (!bullets.empty())
	{
		for (int i = 0; i < (int)bullets.size(); i++)
		{
			bullets[i]->update();
		}

		for (int i = 0; i < (int)bullets.size(); i++)
		{
			if (bullets[i]->getActive() == false)
			{
				delete bullets[i];
				bullets[i] = nullptr;
			}
		}

		bullets.erase(std::remove(bullets.begin(), bullets.end(), nullptr), bullets.end());
	}

}

void Ranged::updateAI(bool attack)
{
	pos.x = hold_pos.x + (holdrange * cos(rotation)) - pos.w / 2;
	pos.y = hold_pos.y + (holdrange * sin(rotation)) - pos.h / 2;

	if (attack == true)
	{
		if (attackTimer == 0)
		{
			bullets.push_back(new Bullet(pos.x, pos.y, 5, 5, 10, rotation, ai, bulletid));
			AudioManager::getInstance().playSound(blastid, -1, 0);
			attackTimer = attackspeedduration;
		}
	}
	if (attackTimer > 0)
	{
		attackTimer--;
	}

	if (!bullets.empty())
	{
		for (int i = 0; i < (int)bullets.size(); i++)
		{
			bullets[i]->update();
		}

		for (int i = 0; i < (int)bullets.size(); i++)
		{
			if (bullets[i]->getActive() == false)
			{
				delete bullets[i];
				bullets[i] = nullptr;
			}
		}

		bullets.erase(std::remove(bullets.begin(), bullets.end(), nullptr), bullets.end());
	}
}

void Ranged::render()
{
	inner = { pos.x - 1, pos.y + 1, pos.w - 2, pos.h - 2 };
	if (!bullets.empty())
	{
		for (int i = 0; i < (int)bullets.size(); i++)
		{
			bullets[i]->render();
		}
	}

	if (active == true)
	{
		TextureManager::getInstance().drawEX(texture, NULL, &pos, (rotation * 180 / 3.14) + 90, NULL, SDL_FLIP_NONE);
	}
}

void Ranged::setPos(int x, int y)
{
	hold_pos.x = x;
	hold_pos.y = y;
}

void Ranged::setRot(double rot)
{
	rotation = rot;
}

void Ranged::setActive(bool input)
{
	active = input;
}

Ranged::~Ranged()
{
}
