#pragma once
#include "engine.h"
#include "node.h"

class node;
class PathfindingManager
{
private:
	std::vector<node*> nodes;
	int rows, cols;

private:
	PathfindingManager();
	void checkneighbours(node* current);
	void resetNodes();

public:
	static PathfindingManager& getInstance();
	bool init();
	void clean();
	void clearNodes();
	node*  addNode(int x, int y, int w, int h, bool passable, bool flee);
	void loadNeighbours();
	bool findPath(std::vector<SDL_Point>* path, int startx, int starty, int endx, int endy);
	void setRowCol(int rowin, int colin);
	int getNodeNum();
	node* getNode(int i);
	bool findFlee(std::vector<SDL_Point>* path, int startx, int starty);
	~PathfindingManager();
};

