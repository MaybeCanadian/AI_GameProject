#pragma once
#include "Ranged.h"

class Bullet
{
private:
	SDL_Rect pos;
	double rotation;
	double speed;
	double velx, vely, accelx, accely, drag, maxVel;
	bool active;
	bool ai;
	int texture;

private:
	void checkcollision();
	void checkCollisionAI();

public:
	Bullet(int x, int y, int w, int h, double accel, double rot, bool ty, int id);
	void update();
	void updateAI();
	void render();
	bool getActive();
	SDL_Rect* getRect();
	~Bullet();
};

