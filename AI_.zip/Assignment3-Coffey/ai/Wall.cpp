#include "Wall.h"


Wall::Wall(int x, int y, int w, int h, int id, node* wallnode, int sound)
{
	pos = { x, y, w, h };
	buffer = wallnode;
	textureId = id;
	soundid = sound;
}

Wall::Wall()
{
}

void Wall::render()
{
	TextureManager::getInstance().draw(textureId, NULL, &pos);
}

void Wall::update()
{
}

SDL_Rect * Wall::getRect()
{
	return &pos;
}

bool Wall::getActive()
{
	return true;
}

void Wall::onHit(int damage, int inv)
{
	AudioManager::getInstance().playSound(soundid, -1, 0);
}

Wall::~Wall()
{
}
