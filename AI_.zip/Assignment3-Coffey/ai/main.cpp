#include "engine.h"

int main(int argc, char* args[])
{
	return engine::getInstance().run();
}