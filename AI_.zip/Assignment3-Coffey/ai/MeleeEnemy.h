#pragma once
#include "Enemy.h"
#include "Melee.h"


class Melee;
class node;
class MeleeEnemy :
	public Enemy
{
private:
	Melee* fist;
	int texture, fistid, punchid;

private:
	void Attack();
public:
	MeleeEnemy(int x, int y, int id, int melid, int punch, int hitid);
	void update();
	void render();
	~MeleeEnemy();
};

