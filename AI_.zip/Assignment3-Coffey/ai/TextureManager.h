#pragma once
#include <SDL_image.h>

#include "engine.h"

class TextureManager
{
private:
	SDL_Renderer* t_pRenderer;
	SDL_Window* t_pWindow;

	std::vector<SDL_Texture*> textures;

private:
	TextureManager();

public:
	static TextureManager& getInstance();
	bool init(const char * title, int xpos, int ypos, int width, int height, int flags);
	int addTexture(std::string input);
	void draw(int id, SDL_Rect* area, SDL_Rect* pos);
	void drawEX(int id, SDL_Rect* area, SDL_Rect* pos, double rot, SDL_Point* centre, SDL_RendererFlip flips);
	void clean();
	void setDrawColour(Uint8 r, Uint8 g, Uint8 b, Uint8 a);
	void fillRect(SDL_Rect* pos);
	void renderPresent();
	void renderClear();
	~TextureManager();
};

