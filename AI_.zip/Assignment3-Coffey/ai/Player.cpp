#include "Player.h"

void Player::move()
{
	accelx = Util::min(Util::max(accelx, -maxAccel), maxAccel);
	accely = Util::min(Util::max(accely, -maxAccel), maxAccel);

	velx = (velx + accelx) * drag;
	vely = (vely + accely) * drag;

	velx = Util::min(Util::max(velx, -maxVel), maxVel);
	vely = Util::min(Util::max(vely, -maxVel), maxVel);

	dst.x = dst.x + (int)velx;
	dst.y = dst.y + (int)vely;

	checkCollisions();
}

void Player::followMouse()
{
	SDL_Point mouse = *InputManager::getInstance().getMouse();
	SDL_Point buffer = { dst.x + dst.w / 2, dst.y + dst.h / 2 };

	rotation = Util::Rotation(&mouse, &buffer);
	
	switch (currentWep)
	{
	case melee:
		{
		fist->setRotation(rotation);
		fist->setPos(dst.x + dst.w / 2, dst.y + dst.h / 2);
		fist->update();
		gun->update();
		break;
		}
	case ranged:
		{
		gun->setRot(rotation);
		gun->setPos(dst.x + dst.w / 2, dst.y + dst.h / 2);
		gun->update();
		break;
		}
	}
}

void Player::checkCollisions()
{
	if (dst.x < 0 || dst.x + dst.w > WIDTH)
	{
		dst.x = dst.x - (int)velx;
		velx = 0;
	}
	if (dst.y < 0 || dst.y + dst.h > HEIGHT)
	{
		dst.y = dst.y - (int)vely;
		vely = 0;
	}

	for (int i = 0; i < LevelManager::getInstance().getWallSize(); i++)
	{
		if (SDL_HasIntersection(&dst, LevelManager::getInstance().getWall(i)->getRect()))
		{
			correctcollision(LevelManager::getInstance().getWall(i)->getRect());
		}
	}
}

void Player::correctcollision(SDL_Rect * plat)
{
	if (dst.y + dst.w - vely <= plat->y)
	{
		dst.y = plat->y - dst.h - 1;
		vely = 0;
	}
	if (dst.y - vely >= plat->y + plat->h)
	{
		dst.y = plat->y + plat->h + 1;
		vely = 0;
	}
	if (dst.x + dst.w - velx <= plat->x)
	{
		dst.x = plat->x - dst.w - 1;
		velx = 0;
	}
	if (dst.x - velx >= plat->x + plat->w)
	{
		dst.x = plat->x + plat->w + 1;
		velx = 0;
	}
}

void Player::dash()
{
	velx = (velx + dashaccelx) * drag;
	vely = (vely + dashaccely) * drag;

	velx = Util::min(Util::max(velx, -maxVeldash), maxVeldash);
	vely = Util::min(Util::max(vely, -maxVeldash), maxVeldash);

	dst.x = dst.x + (int)velx;
	dst.y = dst.y + (int)vely;

	checkCollisions();
}

Player::Player(int id, int rangid, int bulid, int melid, int blastid, int punchid)
{
	textureID = id;
	rangedid = rangid;
	bulletid = bulid;
	fistid = melid;
	shotid = blastid;
	attackid = punchid;
	dst = { GRID * 12, 0, 25, 25 };
	health = new HealthBar(dst.w + 4, 5);
	fist = new Melee(15, 15, 30, melid, attackid);
	gun = new Ranged(10, 10, 20, 30, false, rangedid, bulletid, shotid);
	accelx = accely = velx = vely = 0;
	maxAccel = 10;
	accel = 10;
	maxVel = 5;
	drag = 0.9;
	gundist = 25;
	currentWep = melee;
	wepSwapTimer = 0;
	dashTimer = 0;
	dashDuration = 0;
	maxVeldash = 10;
	dashing = false;
	dashaccelx = dashaccely = 0;
	dashaccel = 25;
	active = true;
	
}

void Player::update()
{
	followMouse();

	if (InputManager::getInstance().keyDown(SDL_SCANCODE_W))
	{
		accely = accely - accel;
	}
	if (InputManager::getInstance().keyDown(SDL_SCANCODE_S))
	{
		accely = accely + accel;
	}
	if (InputManager::getInstance().keyDown(SDL_SCANCODE_A))
	{
		accelx = accelx - accel;
	}
	if (InputManager::getInstance().keyDown(SDL_SCANCODE_D))
	{
		accelx = accelx + accel;
	}

	if (dashTimer == 0)
	{
		if (InputManager::getInstance().getMouseClick(SDL_BUTTON_RIGHT))
		{
			dashing = true;
			dashTimer = 60;
			dashDuration = 10;
			dashaccelx = accelx * 3;
			dashaccely = accely * 3;
		}
	}
	else
	{
		dashTimer--;
	}

	if(wepSwapTimer == 0)
	{
		if (currentWep == melee)
		{
			if (InputManager::getInstance().keyDown(SDL_SCANCODE_2) || InputManager::getInstance().getscroll())
			{
				currentWep = ranged;
				fist->wepChange();
				gun->setActive(true);
				wepSwapTimer = 30;
			}
		}
		else if (currentWep == ranged)
		{
			if (InputManager::getInstance().keyDown(SDL_SCANCODE_1) || InputManager::getInstance().getscroll())
			{
				currentWep = melee;
				gun->setActive(false);
				wepSwapTimer = 30;
			}
		}
	}
	else
	{
		wepSwapTimer--;
	}

	if (dashing == true)
	{
		if (dashDuration == 0)
		{
			dashing = false;
		}
		else
		{
			dashDuration--;
		}
		dash();
	}
	else
	{
		move();
	}

	followMouse();

	health->updatePos(dst.x, dst.y - 10);

	accelx = 0;
	accely = 0;

	if (invaul > 0)
	{
		invaul--;
	}


	if (health->getHealth() == 0)
	{
		active = false;
		StateMachine::getInstance().changeState(lose);
	}
}

void Player::render()
{
	TextureManager::getInstance().draw(textureID, NULL, &dst);

	health->render();


	SDL_Point mouse = *InputManager::getInstance().getMouse();
	SDL_Point buffer = { dst.x + dst.w / 2, dst.y + dst.h / 2 };

	rotation = Util::Rotation(&mouse, &buffer);

	fist->setRotation(rotation);

	switch (currentWep)
	{
	case melee:
	{
		fist->render();
		gun->render();
		break;
	}
	case ranged:
	{
		gun->render();
		break;
	}
	}
}

SDL_Rect * Player::getRect()
{
	return &dst;
}

void Player::onHit(int damage, int inv)
{
	if (invaul == 0)
	{
		health->takeDamage(damage);
		invaul = inv;
	}
}

bool Player::getAcive()
{
	return active;
}

Player::~Player()
{
	delete health;
	delete fist;
	delete gun;
}
