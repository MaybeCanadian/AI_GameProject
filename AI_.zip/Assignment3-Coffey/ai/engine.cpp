#include "engine.h"

engine::engine()
{
	running = false;
}

void engine::wake()
{
	start = SDL_GetTicks();
}

void engine::sleep()
{
	end = SDL_GetTicks();

	delta = end - start;

	if (delta < fps)
	{
		SDL_Delay(fps - delta);
	}
}

void engine::update()
{
	StateMachine::getInstance().update();
}

void engine::render()
{
	StateMachine::getInstance().render();
}

void engine::handleEvents()
{
	StateMachine::getInstance().handleEvents();
}

void engine::clean()
{
	//call all the systems clean fucntions
	TextureManager::getInstance().clean();
	AudioManager::getInstance().clean();
	StateMachine::getInstance().clean();
	ObjectManager::getInstance().clean();
	InputManager::getInstance().clean();
	UiManager::getInstance().clean();
	BackGroundManager::getInstance().clean();
	LevelManager::getInstance().clean();
	PathfindingManager::getInstance().clean();

	std::cout << std::endl << "All systems cleaned" << std::endl;
}

bool engine::init(const char * title, int xpos, int ypos, int width, int height, int flags)
{
	if (TextureManager::getInstance().init(title, xpos, ypos, width, height, flags) == true)
	{
		if (AudioManager::getInstance().init() == true)
		{
			if (UiManager::getInstance().init() == true)
			{
				if (StateMachine::getInstance().init() == true)
				{
					if (ObjectManager::getInstance().init() == true)
					{
						if (InputManager::getInstance().init() == true)
						{
							if (BackGroundManager::getInstance().init() == true)
							{
								if (LevelManager::getInstance().init() == true)
								{
									if (PathfindingManager::getInstance().init() == true)
									{

									}
									else
										return false;
								}
								else
									return false;
							}
							else
								return false;
						}
						else
							return false;
					}
					else
						return false;
				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
	}
	else
		return false;

	fps = (Uint32)round(1 / (double)FPS * 1000);
	running = true;
	return true;
}

engine & engine::getInstance()
{
	static engine instance;
	return instance;
}

int engine::run()
{
	if (init("ai", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, 0) == false)
	{
		return 1;
	}

	while (running == true)
	{
		wake();

		handleEvents();
		update();
		render();

		if (running == true)
		{
			sleep();
		}
	}

	clean();
	return 0;
}

void engine::quit()
{
	running = false;
}


engine::~engine()
{
}
