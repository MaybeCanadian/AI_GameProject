#include "Melee.h"

void Melee::checkCollision()
{
	if (attacking == true)
	{
		for (int i = 0; i < LevelManager::getInstance().getWallSize(); i++)
		{
			if (SDL_HasIntersection(&pos, LevelManager::getInstance().getWall(i)->getRect()))
			{
				LevelManager::getInstance().getWall(i)->onHit(25, 30);
			}
		}

		for (int i = 0; i < ObjectManager::getInstance().getEnemySize(); i++)
		{
			if (SDL_HasIntersection(&pos, ObjectManager::getInstance().getEnemy(i)->getRect()))
			{
				ObjectManager::getInstance().getEnemy(i)->onHit(25, 30);
			}
		}
	}
}

void Melee::checkCollisionAI()
{
	if (attacking == true)
	{
		for (int i = 0; i < LevelManager::getInstance().getWallSize(); i++)
		{
			if (SDL_HasIntersection(&pos, LevelManager::getInstance().getWall(i)->getRect()))
			{
				LevelManager::getInstance().getWall(i)->onHit(25, 30);
			}
		}

		for (int i = 0; i < ObjectManager::getInstance().getPlayerSize(); i++)
		{
			if (SDL_HasIntersection(&pos, ObjectManager::getInstance().getPlayer(i)->getRect()))
			{
				ObjectManager::getInstance().getPlayer(i)->onHit(25, 30);
			}
		}
	}
}

Melee::Melee(int w, int h, int range, int id, int sound)
{
	pos = { 0, 0, w, h };
	rotation = 0;
	fistrange = range;
	attacking = false;
	attackrange = 0;
	textureid = id;
	soundid = sound;
}

void Melee::update()
{
	if (attacking == false)
	{
		if (InputManager::getInstance().getMouseClick(SDL_BUTTON_LEFT))
		{
			AudioManager::getInstance().playSound(soundid, -1, 0);
			attacking = true;
			attackTimer = 0;
		}
	}
	else
	{
		if (attackTimer < 5)
		{
			if (attackrange < 30)
			{
				attackrange = attackrange + 6;
			}
		}
		else if (attackTimer < 15)
		{
		}
		else if (attackTimer < 20)
		{
			if (attackrange > 0)
			{
				attackrange = attackrange - 6;
			}
		}
		else
		{
			attacking = false;
		}

		attackTimer++;
	}
	pos.x = holdPos.x + cos(rotation) * (fistrange + attackrange) - pos.w /2;
	pos.y = holdPos.y + sin(rotation) * (fistrange + attackrange) - pos.h /2;

	checkCollision();

}

void Melee::updateAI(bool attack)
{
	if (attacking == false)
	{
		if (attack == true)
		{
			AudioManager::getInstance().playSound(soundid, -1, 0);
			attacking = true;
			attackTimer = 0;
		}
	}
	else
	{
		if (attackTimer < 5)
		{
			if (attackrange < 30)
			{
				attackrange = attackrange + 6;
			}
		}
		else if (attackTimer < 15)
		{
		}
		else if (attackTimer < 20)
		{
			if (attackrange > 0)
			{
				attackrange = attackrange - 6;
			}
		}
		else
		{
			attacking = false;
		}

		attackTimer++;
	}

	pos.x = holdPos.x + cos(rotation) * (fistrange + attackrange) - pos.w / 2;
	pos.y = holdPos.y + sin(rotation) * (fistrange + attackrange) - pos.h / 2;

	checkCollisionAI();
}

void Melee::render()
{
	TextureManager::getInstance().drawEX(textureid, NULL, &pos, (rotation * 180 / 3.14) + 90, NULL, SDL_FLIP_NONE);
}

void Melee::setPos(int x, int y)
{
	holdPos.x = x;
	holdPos.y = y;
}

void Melee::setRotation(double rot)
{
	rotation = rot;
}

bool Melee::getAttacking()
{
	return attacking;
}

SDL_Rect * Melee::getRect()
{
	return &pos;
}

void Melee::wepChange()
{
	attackrange = 0;
	attackTimer = 0;
	attacking = false;
}


Melee::~Melee()
{
}
