#pragma once
#include "engine.h"

class BackGroundManager
{
private:
	SDL_Rect backing;

private:
	BackGroundManager();
public:
	static BackGroundManager& getInstance();
	bool init();
	void clean();
	void update();
	void GameRender();
	void MenuRender();
	~BackGroundManager();
};

