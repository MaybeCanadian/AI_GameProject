#pragma once
#include "State.h"
class StateWin :
	public State
{
private:
	int soundid;
public:
	StateWin();
	void update();
	void render();
	void handleEvents();
	void enter();
	void exit();
	~StateWin();
};

