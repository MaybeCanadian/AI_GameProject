#pragma once
#include "Player.h"
#include "Bullet.h"

class Bullet;
class Ranged
{
private:
	SDL_Rect pos;
	SDL_Rect inner;
	SDL_Point hold_pos;
	double rotation;
	int holdrange;
	bool active;

	bool ai;

	int texture, bulletid, blastid;

	int attackTimer;
	int attackspeedduration;

	std::vector<Bullet*> bullets;

public:
	Ranged(int w, int h, int hold, int attackspeed, bool ty, int id, int bulid, int shotid);
	void update();
	void updateAI(bool attack);
	void render();
	void setPos(int x, int y);
	void setRot(double rot);
	void setActive(bool input);
	~Ranged();
};

