#include "Enemy.h"



void Enemy::Flee()
{
		if (exit == false)
		{
			clearPath();
			if (PathfindingManager::getInstance().findFlee(&path, pos.x, pos.y))
			{
				exit = true;
			}
		}
		else
		{
			if (path.size() == 1)
			{
				active = false;
			}
			else
			{
				seek(&path.front());
			}
		}
}

void Enemy::seek(SDL_Point * target)
{
	desx = ((target->x - (pos.x + pos.w / 2)) / sqrt(pow(target->x - (pos.x + pos.w / 2), 2) + pow(target->y - (pos.y + pos.h / 2), 2))) * MaxVel;
	desy = ((target->y - (pos.y + pos.h / 2)) / sqrt(pow(target->x - (pos.x + pos.w / 2), 2) + pow(target->y - (pos.y + pos.h / 2), 2))) * MaxVel;

	steerx = desx - velx;
	steery = desy - vely;

	steerx = Util::Trunacate(steerx, Maxforce);
	steery = Util::Trunacate(steery, Maxforce);

	velx = Util::Trunacate(velx + steerx, MaxVel);
	vely = Util::Trunacate(vely + steery, MaxVel);

	pos.x = pos.x + (int)velx;
	pos.y = pos.y + (int)vely;

	SDL_Rect buffer = { target->x, target->y, 1, 1 };
	if (Util::distance(&pos, &buffer) < 40)
	{
		path.erase(path.begin());
	}
}

void Enemy::checklow()
{
	if (ObjectManager::getInstance().getEnemySize() > 1)
	{
		if (health->getHealth() < 25)
		{
			state = fleeing;
		}
		else
		{
			if (state == fleeing)
			{
				state = idle;
			}
		}
	}
	else
	{
		if (health->getHealth() < 50)
		{
			state = fleeing;
		}
		else
		{
			if (state == fleeing)
			{
				state = idle;
			}
		}
	}
}

void Enemy::clearPath()
{
	if (!path.empty())
	{
		path.clear();
		path.shrink_to_fit();
	}
}

void Enemy::Idle()
{
	if (health->getHealth() < 100)
	{
		lookrange = 10000;
	}

	if (look() == true)
	{
		state = attacking;
		lookrange = 10000;
	}
	else
	{
		if (wandergoal == 0)
		{
			srand(time(NULL));

			int random = rand();

			wandergoal = random % 60 + 60;

			bool invalid = true;

			while (invalid == true)
			{
				srand(random);

				random = rand();

				wanderplace = random % PathfindingManager::getInstance().getNodeNum();

				std::cout << "wander place is " << wanderplace << std::endl;

				clearPath();

				if (PathfindingManager::getInstance().getNode(wanderplace)->getPassable() == true)
				{
					invalid = false;
				}
			}

			PathfindingManager::getInstance().findPath(&path, pos.x, pos.y, PathfindingManager::getInstance().getNode(wanderplace)->getPoint()->x, PathfindingManager::getInstance().getNode(wanderplace)->getPoint()->y);

			wandertimer = 0;

		}
		else
		{
			if (wandertimer > wandergoal)
			{
				if (!path.empty())
				{
					seek(&path.front());
				}
				else
				{
					wanderplace = 0;
					wandertimer = 0;
					wandergoal = 0;
				}
			}
			else
			{
				wandertimer++;
			}
		}
	}
}

void Enemy::AI()
{

	checklow();
	shouldattack = false;
	switch (state)
	{
	case idle:
	{
		Idle();
		break;
	}
	case attacking:
	{
		Attack();
		break;
	}
	case backing:
	{
		break;
	}
	case fleeing:
	{
		Flee();
		break;
	}
	}
}

void Enemy::Attack()
{
}

bool Enemy::look()
{
	for (int i = 0; i < ObjectManager::getInstance().getPlayerSize(); i++)
	{
		if (Util::distance(&pos, ObjectManager::getInstance().getPlayer(i)->getRect()) < lookrange)
		{
			nearPlayer = { ObjectManager::getInstance().getPlayer(i)->getRect()->x, ObjectManager::getInstance().getPlayer(i)->getRect()->y };
			return true;
		}
	}

	return false;
}

Enemy::Enemy()
{
	active = true;
	invlual = 0;
	rotation = 0;
	velx = vely = desx = desy = steerx = steery = 0;
	state = idle;
	nearPlayer = { 0 , 0 };
	MaxVel = 4;
	Maxforce = 2;
	lookrange = 200;
	exit = false;
}


bool Enemy::getActive()
{
	return active;
}

SDL_Rect * Enemy::getRect()
{
	return &pos;
}

void Enemy::onHit(int damage, int inv)
{
	if (invlual == 0)
	{
		AudioManager::getInstance().playSound(hit, -1, 0);
		health->takeDamage(damage);
		invlual = inv;
	}
}

Enemy::~Enemy()
{
	delete health;
}
