#include "StateGame.h"



StateGame::StateGame()
{
}

void StateGame::update()
{
	BackGroundManager::getInstance().update();
	LevelManager::getInstance().update();
	ObjectManager::getInstance().update();
}

void StateGame::render()
{
	BackGroundManager::getInstance().GameRender();
	LevelManager::getInstance().render();
	ObjectManager::getInstance().render();
}

void StateGame::handleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			engine::getInstance().quit();
			break;
		case SDL_KEYDOWN: // records a key press event
			if (event.key.keysym.sym == SDLK_ESCAPE)
				StateMachine::getInstance().changeState(pause);
			break;
		case SDL_MOUSEBUTTONDOWN: //records a mouse down event
			InputManager::getInstance().mouseDown(event.button.button);
			break;
		case SDL_MOUSEBUTTONUP: //records a mouse up event
			InputManager::getInstance().mouseUp(event.button.button);
			break;
		case SDL_MOUSEWHEEL:
			InputManager::getInstance().mouseScrollevent();
			break;
		}
	}
}

void StateGame::exit()
{
}

void StateGame::enter()
{
}


StateGame::~StateGame()
{
}
