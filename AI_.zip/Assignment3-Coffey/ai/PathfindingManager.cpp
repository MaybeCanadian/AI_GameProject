#include "PathfindingManager.h"



PathfindingManager::PathfindingManager()
{
}

void PathfindingManager::checkneighbours(node* current)
{
	if (current->getNeighbour(0) != nullptr)
	{
		if (!current->getNeighbour(0)->getBoolData(2))
		{
			if (current->getNeighbour(0)->getDist() > current->getDist() + current->getNeighbour(0)->getCost())
			{
				current->getNeighbour(0)->setDist(current->getDist() + current->getNeighbour(0)->getCost());
				current->getNeighbour(0)->setParent(current);
			}
		}
	}

	//check right
	if (current->getNeighbour(1) != nullptr)
	{
		if (!current->getNeighbour(1)->getBoolData(2))
		{
			if (current->getNeighbour(1)->getDist() > current->getDist() + current->getNeighbour(1)->getCost())
			{
				current->getNeighbour(1)->setDist(current->getDist() + current->getNeighbour(1)->getCost());
				current->getNeighbour(1)->setParent(current);
			}
		}
	}

	//check down
	if (current->getNeighbour(2) != nullptr)
	{
		if (!current->getNeighbour(2)->getBoolData(2))
		{
			if (current->getNeighbour(2)->getDist() > current->getDist() + current->getNeighbour(2)->getCost())
			{
				current->getNeighbour(2)->setDist(current->getDist() + current->getNeighbour(2)->getCost());
				current->getNeighbour(2)->setParent(current);
			}
		}
	}

	//check left
	if (current->getNeighbour(3) != nullptr)
	{
		if (!current->getNeighbour(3)->getBoolData(2))
		{
			if (current->getNeighbour(3)->getDist() > current->getDist() + current->getNeighbour(3)->getCost())
			{
				current->getNeighbour(3)->setDist(current->getDist() + current->getNeighbour(3)->getCost());
				current->getNeighbour(3)->setParent(current);
			}
		}
	}
}

void PathfindingManager::resetNodes()
{
	if (!nodes.empty())
	{
		for (int i = 0; i < (int)nodes.size(); i++)
		{
			nodes[i]->resetNode();
		}
	}
}

PathfindingManager & PathfindingManager::getInstance()
{
	static PathfindingManager instance;
	return instance;
}

bool PathfindingManager::init()
{
	rows = cols = 0;
	std::cout << "Path finder Loaded." << std::endl;
	return true;
}

void PathfindingManager::clean()
{
	clearNodes();
	std::cout << "Path Finder cleaned." << std::endl;
}

void PathfindingManager::clearNodes()
{
	if (!nodes.empty())
	{
		for (int i = 0; i < (int)nodes.size(); i++)
		{
			delete nodes[i];
			nodes[i] = nullptr;
		}

		nodes.clear();
		nodes.shrink_to_fit();
	}
}

node* PathfindingManager::addNode(int x, int y, int w, int h, bool passable, bool flee)
{
	nodes.push_back(new node( x, y,  passable, flee));
	return nodes.back();
}

void PathfindingManager::loadNeighbours()
{
	if(!nodes.empty())
	{
		for (int i = 0; i < nodes.size(); i++)
		{
			nodes[i]->resetNeighbours();
		}
		for (int i = 0; i < (int)nodes.size(); i++)
		{
			if (nodes[i]->getPassable() == true)
			{
				//load up
				if (i >= cols)
				{
					if (nodes[i - cols]->getPassable() == true)
					{
						nodes[i]->setNeighbour(0, nodes[i - cols]);
					}
				}

				//load right
				if ((i + 1) % cols != 0)
				{
					if (nodes[i + 1]->getPassable() == true)
					{
						nodes[i]->setNeighbour(1, nodes[i + 1]);
					}
				}

				//load down
				if (i < (cols * rows - cols))
				{
					if (nodes[i + cols]->getPassable() == true)
					{
						nodes[i]->setNeighbour(2, nodes[i + cols]);
					}
				}

				//load left
				if (i % cols != 0)
				{
					if (nodes[i - 1]->getPassable() == true)
					{
						nodes[i]->setNeighbour(3, nodes[i - 1]);
					}
				}
			}
		}
	}
}

bool PathfindingManager::findPath(std::vector<SDL_Point>* path, int startx, int starty, int endx, int endy)
{
	resetNodes();
	std::vector<node*> unvisited;

	for (int i = 0; i < (int)nodes.size(); i++)
	{
		unvisited.push_back(nodes[i]);
	}

	int startpoint = (int)(startx / GRID) + (int)((starty / GRID) * cols);
	int endpoint = (int)(endx / GRID) + (int)((endy / GRID) * cols);
	int current = -1;
	int lowestDist = 1000;

	nodes[startpoint]->setBoolData(0, true); //finding the nodes that we start and end at
	nodes[startpoint]->setDist(0);
	nodes[endpoint]->setBoolData(1, true);

	bool atEnd = false; //flag to hold the while loop

	if (startpoint == endpoint)
	{
		path->clear();
		atEnd == true;
		path->insert(path->begin(), *(nodes[endpoint]->getPoint()));
		return true;
	}


	while (!atEnd)
	{
		current = -1;
		lowestDist = 999;
		for (int i = 0; i < (int)unvisited.size(); i++)
		{
			if (unvisited[i]->getDist() < lowestDist)
			{
				lowestDist = unvisited[i]->getDist();
				current = i;
			}
		}

		if (current == -1)
		{
			return false;
		}

		if (unvisited[current]->getBoolData(1))
		{
			atEnd = true;
		}
		else
		{
			checkneighbours(unvisited[current]);
			unvisited[current]->setBoolData(2, true);
			unvisited.erase(unvisited.begin() + current);
		}
	}

	bool atStart = false;

	node* current_node = unvisited[current];

	path->clear();

	while (current_node->getBoolData(0) == false)
	{
		SDL_Point buffer = { current_node->getPoint()->x + GRID / 2 , current_node->getPoint()->y + GRID / 2 };
		path->insert((path->begin()), buffer);
		current_node = current_node->getParent();
	}


	return true;
}

void PathfindingManager::setRowCol(int rowin, int colin)
{
	rows = rowin;
	cols = colin;
}

int PathfindingManager::getNodeNum()
{
	return nodes.size();
}

node * PathfindingManager::getNode(int i)
{
	return nodes[i];
}

bool PathfindingManager::findFlee(std::vector<SDL_Point>* path, int startx, int starty)
{
	std::vector<node*> unvisited;

	for (int i = 0; i < (int)nodes.size(); i++)
	{
		unvisited.push_back(nodes[i]);
	}

	int startpoint = (int)(startx / GRID) + (int)((starty / GRID) * cols);
	int current = -1;
	int lowestDist = 1000;

	nodes[startpoint]->setBoolData(0, true); //finding the nodes that we start and end at
	nodes[startpoint]->setDist(0);

	bool atEnd = false; //flag to hold the while loop

	if (nodes[startpoint]->getFlee() == true)
	{
		path->clear();
		atEnd == true;
		path->insert(path->begin(), *(nodes[startpoint]->getPoint()));
		return true;
	}


	while (!atEnd)
	{
		current = -1;
		lowestDist = 999;
		for (int i = 0; i < (int)unvisited.size(); i++)
		{
			if (unvisited[i]->getDist() < lowestDist)
			{
				lowestDist = unvisited[i]->getDist();
				current = i;
			}
		}

		if (current == -1)
		{
			return false;
		}

		if (unvisited[current]->getFlee())
		{
			atEnd = true;
		}
		else
		{
			checkneighbours(unvisited[current]);
			unvisited[current]->setBoolData(2, true);
			unvisited.erase(unvisited.begin() + current);
		}
	}

	bool atStart = false;

	node* current_node = unvisited[current];

	path->clear();

	SDL_Point buffer = { 0, 0 };
	path->insert((path->begin()), buffer);

	while (current_node->getBoolData(0) == false)
	{
		SDL_Point buffer = { current_node->getPoint()->x + GRID / 2 , current_node->getPoint()->y + GRID / 2 };
		path->insert((path->begin()), buffer);
		current_node = current_node->getParent();
	}

	resetNodes();
	return true;
}

PathfindingManager::~PathfindingManager()
{
}
