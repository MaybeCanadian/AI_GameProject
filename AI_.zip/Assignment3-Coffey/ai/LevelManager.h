#pragma once
#include <fstream>

#include "engine.h"
#include "Wall.h"

#define GRID 40

class Wall;
class node;
class LevelManager
{
private:
	std::vector<Wall*> walls;
	int wallID, destructID, hitsound;
	bool reload;

private:
	LevelManager();

public:
	static LevelManager& getInstance();
	bool init();
	void clean();
	bool LoadLevel();
	void clearWalls();
	void update();
	void render();
	int getWallSize();
	Wall* getWall(int i);
	~LevelManager();
};

