#include "BackGroundManager.h"



BackGroundManager::BackGroundManager()
{
}


BackGroundManager & BackGroundManager::getInstance()
{
	static BackGroundManager instance;
	return instance;
}

bool BackGroundManager::init()
{
	backing = { 0, 0, WIDTH, HEIGHT };
	std::cout << "Background Manager Loaded." << std::endl;
	return true;
}

void BackGroundManager::clean()
{
	std::cout << "BackGround Manager cleaned." << std::endl;
}

void BackGroundManager::update()
{
}

void BackGroundManager::GameRender()
{
	TextureManager::getInstance().setDrawColour(0, 0, 0, 255);
	TextureManager::getInstance().fillRect(&backing);
}

void BackGroundManager::MenuRender()
{
	TextureManager::getInstance().setDrawColour(0, 0, 0, 255);
	TextureManager::getInstance().fillRect(&backing);
}

BackGroundManager::~BackGroundManager()
{
}
